<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require $_SERVER['DOCUMENT_ROOT'].'/vendor/autoload.php';
require 'Parsedown.php';


use Symfony\Component\Yaml\Yaml;

function ajax_request() {
	$ajax_contents = file_get_contents( 'php://input' );
	return (array) json_decode($ajax_contents);
}
$af_post = ajax_request();

$folderPath = 'articles/';


if ( ! function_exists('pre') ) {
	function pre($var) {
		echo "<!-- rsprsp: --><pre style='background-color: #ffffcc; border-radius: 4px; border: 1px solid #003366; color: #003366; font-size: 11px; line-height: 12px; padding: 4px;'>";
		print_r($var);
		echo "</pre>";
	}
}


function yaml_parse($yamlString) {
	try {
		$parsedYaml = Yaml::parse($yamlString);
		return $parsedYaml;
	} catch (Exception $e) {
		echo "Error parsing YAML: " . $e->getMessage();
		return null;
	}
}





$Parsedown = new Parsedown();






function parseMarkdownWithFrontMatter($content,$fname,$type = 'all') {
	$frontMatter = [];
	$markdown = '';
	if (preg_match('/^---\s*\n(.*?)\n---\s*\n(.*)/s', $content, $matches)) {
		$frontMatterString = $matches[1];
		$markdown = $matches[2];
		$frontMatter = yaml_parse($frontMatterString);
	} else {
		$markdown = $content;
	}
	$parsedown = new Parsedown();
	$html = $parsedown->text($markdown);
	if($type == 'frontMatter') {
		return [
			'fname' => $fname,
			'frontMatter' => $frontMatter
		];
	}
	if($type == 'html') {
		return [
			'fname' => $fname,
			'html' => $html
		];
	}
	if($type == 'all') {
		return [
			'fname' => $fname,
			'frontMatter' => $frontMatter,
			'html' => $html,
			'md' => $markdown,
		];
	}
}





function readMarkdownFiles($folderPath) {
	$markdownFiles = [];

	if ($handle = opendir($folderPath)) {

		while (false !== ($entry = readdir($handle))) {

			if (pathinfo($entry, PATHINFO_EXTENSION) === 'md') {

				$fileContent = file_get_contents($folderPath . DIRECTORY_SEPARATOR . $entry);



				$markdownFiles[$entry] = parseMarkdownWithFrontMatter($fileContent,$entry,'frontMatter');
			}
		}

		closedir($handle);
	}

	return $markdownFiles;
}


function getmdfile($filename) {
	global $folderPath;
	$file = htmlspecialchars( stripslashes( $filename ));
	$clean_name = base64_decode( $file );
	if(file_exists($folderPath.$clean_name)) {
		$fileContent = file_get_contents($folderPath . DIRECTORY_SEPARATOR . $clean_name);
		$buff = parseMarkdownWithFrontMatter($fileContent,$clean_name,'all');

	}
	return $buff;
}

$markdownFiles = readMarkdownFiles($folderPath);

if(!empty( $af_post['action'] ) ) {

	if($af_post['action'] == 'getmarkdown' && !empty($af_post['file'])) {

		$buff = getmdfile( $af_post['file'] );

		echo $buff['md'];
	}

	if($af_post['action'] == 'postmarkdown' && !empty($af_post['file']) && !empty($af_post['content'])) {

		$file = htmlspecialchars( stripslashes( $af_post['file'] ));
		$clean_name = base64_decode( $file );


		$content = file_get_contents( $folderPath . DIRECTORY_SEPARATOR . $clean_name );

		if (preg_match('/^---\s*\n(.*?)\n---\s*\n(.*)/s', $content, $matches)) {
			$frontMatterString = $matches[1];
		}

		$yamlAndMarkdown = "---
" . $frontMatterString . "
---
" . $af_post['content'];
		file_put_contents( $folderPath . DIRECTORY_SEPARATOR . $clean_name, $yamlAndMarkdown);
		echo 'posted';
	}

	exit();
}
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport"
	      content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel='stylesheet' id='styles'  href='css/toastui-editor.min.css' type='text/css' media='all' />
	<link rel='stylesheet' id='styles'  href='css/style.css?nc=<?php echo rand(1000000,9999999); ?>' type='text/css' media='all' />
	<title>Markdown test</title>
</head>
<body>

<?php
if(!empty($_GET['action']) && $_GET['action'] == 'edit') {
	if(!empty($_GET['file'])) {
		$buff = getmdfile( $_GET['file'] );
		?>
		<input type="hidden" value="<?php echo htmlspecialchars( stripslashes( $_GET['file'] )); ?>" class="js-f_name">
		<h1>editing <?php echo $buff['fname']; ?></h1>
		<div id="editor"></div>
        <br><br>
		<a href="index.php">go back</a> |
		<a href="index.php" class="js-savemd">save changes</a>
		<?php

	}
} else {

	$tools_array = [];
	$author_array = [];
	foreach ($markdownFiles as $mfile) {
	    if(empty($tools_array[$mfile['frontMatter']['tool']])) { $tools_array[$mfile['frontMatter']['tool']] = 0; }
	    if(empty($mfile['frontMatter']['author'])) { $mfile['frontMatter']['author'] = '-'; }
		if(empty($author_array[$mfile['frontMatter']['author']])) { $author_array[$mfile['frontMatter']['author']] = 0; }
		$tools_array[$mfile['frontMatter']['tool']]++;
		$author_array[$mfile['frontMatter']['author']]++;
	}
	?>


	<input type="text" id="mktitle" placeholder="Search by title">

	<select  id="mktool">
		<option value="0">select tool to filter</option>
		<?php
		foreach ($tools_array as $k=>$v) {
			?>
			<option value="<?php echo $k; ?>"><?php echo $k; ?></option>
			<?php
		}
		?>
	</select>


	<select  id="mkauthor">
		<option value="0">select author to filter</option>
		<?php
		foreach ($author_array as $k=>$v) {
			?>
			<option value="<?php echo $k; ?>"><?php echo $k; ?></option>
			<?php
		}
		?>
	</select>

	<table id="mktable">
		<thead>
			<tr>
				<td>#</td>
				<td>url</td>
				<td>title</td>
				<td>&nbsp;</td>
				<td>status</td>
				<td>author</td>
				<td>category</td>
				<td>tool</td>
				<td>views</td>
				<td>published on</td>
				<td>modified on</td>
				<td>&nbsp;</td>
			</tr>
		</thead>
		<?php
		$countfiles = 0;
		foreach ($markdownFiles as $mfile) {
			$countfiles++;
			?>
			<tr>
				<td><?php echo $countfiles; ?></td>
				<td><div class="mkurl"><?php echo $mfile['fname']; ?></div></td>
				<td><?php if(!empty($mfile['frontMatter']['title'])) { echo $mfile['frontMatter']['title']; } else { echo '-'; } ?></td>
				<td><a href="?action=edit&file=<?php echo base64_encode( $mfile['fname'] ); ?>">edit</a></td>
				<td><?php if(!empty($mfile['frontMatter']['status'])) { echo $mfile['frontMatter']['status']; } else { echo '-'; } ?></td>
				<td><?php if(!empty($mfile['frontMatter']['author'])) { echo $mfile['frontMatter']['author']; } else { echo '-'; } ?></td>
				<td><?php if(!empty($mfile['frontMatter']['category'])) { echo $mfile['frontMatter']['category']; } else { echo '-'; } ?></td>
				<td><?php if(!empty($mfile['frontMatter']['tool'])) { echo $mfile['frontMatter']['tool']; } else { echo '-'; } ?></td>
				<td><?php if(!empty($mfile['frontMatter']['views'])) { echo $mfile['frontMatter']['views']; } else { echo '-'; } ?></td>
				<td><?php if(!empty($mfile['frontMatter']['published_on'])) { echo $mfile['frontMatter']['published_on']; } else { echo '-'; } ?></td>
				<td><?php if(!empty($mfile['frontMatter']['modified_on'])) { echo $mfile['frontMatter']['modified_on']; } else { echo '-'; } ?></td>
				<td>publish</td>
			</tr>
			<?php
		}
		?>
	</table>


<?php } ?>



<script src="js/toastui-editor-all.min.js"></script>
<script src="js/scripts.js?rand=<?php echo rand(1000,9999); ?>"></script>
</body>
</html>


