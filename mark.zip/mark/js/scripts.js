document.addEventListener('DOMContentLoaded', function() {
    console.log('start');

    async function npostData( url = '', data = {} ) {
        const response = await fetch( url, {
            method: 'POST',
            mode: 'cors',
            cache: 'no-cache',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/json'
                //'Content-Type': 'application/x-www-form-urlencoded',
            },
            redirect: 'follow',
            referrerPolicy: 'no-referrer',
            body: JSON.stringify( data )
        } );
        return await response;
    }

    var fTitle = function() {
        console.log('filterTitle');
        var input, filter, table, tr, td, i, txtValue;
        input = document.getElementById("mktitle");
        filter = input.value.toUpperCase();
        table = document.getElementById("mktable");
        tr = table.getElementsByTagName("tr");


        for (i = 1; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td")[2];
            if (td) {
                txtValue = td.textContent || td.innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }
        }
    };


    var fTool = function() {
        console.log('filterTool');
        var input, filter, table, tr, td, i, txtValue;
        input = document.getElementById("mktool");
        filter = input.value.toUpperCase();
        table = document.getElementById("mktable");
        tr = table.getElementsByTagName("tr");


        for (i = 1; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td")[7];
            if (td) {
                txtValue = td.textContent || td.innerText;
                console.log(input.value);
                if(input.value === '0') {
                    tr[i].style.display = "";
                } else {
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }

            }
        }
    };

    var fAuthor = function() {
        console.log('filterAuthor');
        var input, filter, table, tr, td, i, txtValue;
        input = document.getElementById("mkauthor");
        filter = input.value.toUpperCase();
        table = document.getElementById("mktable");
        tr = table.getElementsByTagName("tr");


        for (i = 1; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td")[5];
            if (td) {
                txtValue = td.textContent || td.innerText;
                console.log(input.value);
                if(input.value === '0') {
                    tr[i].style.display = "";
                } else {
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }

            }
        }
    };


    if(document.querySelector('#mktitle')) {
        document.querySelector('#mktitle').addEventListener('keyup', function (e) {
            e.preventDefault();
            fTitle();
        });
    }


    if(document.querySelector('#mktool')) {
        document.querySelector('#mktool').addEventListener('change', function (e) {
            e.preventDefault();
            fTool();
        });
    }

    if(document.querySelector('#mkauthor')) {
        document.querySelector('#mkauthor').addEventListener('change', function (e) {
            e.preventDefault();
            fAuthor();
        });
    }



    var mdcontent = '';
    var putontent = function() {
        npostData('?', {
            action: 'postmarkdown',
            file: document.querySelector('.js-f_name').value,
            content: mdcontent,

        })
            .then(data => data.text())
            .then((data) => {
                console.log(data);
                if(data === 'posted') {
                    alert('article updated');
                }
            });
    };



    if(document.querySelector('.js-f_name')) {
        npostData('?', {
            action: 'getmarkdown',
            file: document.querySelector('.js-f_name').value,

        })
            .then(data => data.text())
            .then((data) => {
                const Editor = toastui.Editor;
                const editor = new Editor({
                    el: document.querySelector('#editor'),
                    height: '500px',
                    initialEditType: 'markdown',
                    previewStyle: 'vertical',
                    initialValue: data
                });

                editor.getMarkdown();

                document.querySelector('.js-savemd').addEventListener('click',function(e) {
                   e.preventDefault();
                   console.log('mdd');
                   mdcontent = editor.getMarkdown();
                   putontent();
                });

            });
    }


});